import React from 'react';
import { Star, Quote } from 'lucide-react';

const Reviews = () => {
  const reviews = [
    {
      name: 'Maria Helena, 68 anos',
      role: 'Aposentada',
      rating: 5,
      comment: 'É como voltar à minha infância! O Espaço 60 me transporta para os tempos da Jovem Guarda. O bolo geladeira da vovó é exatamente como minha mãe fazia.',
      decade: '60s',
      image: 'https://images.pexels.com/photos/3768114/pexels-photo-3768114.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
    },
    {
      name: 'Carlos Roberto, 55 anos',
      role: 'Empresário',
      rating: 5,
      comment: 'A Sala 70 é perfeita! Matei a saudade dos vinis enquanto saboreava um café excelente. Meus filhos adoraram conhecer a música da minha época.',
      decade: '70s',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
    },
    {
      name: 'Ana Paula, 42 anos',
      role: 'Professora',
      rating: 5,
      comment: 'O Cantinho 80 é pura nostalgia! As cores neon me lembraram da minha adolescência. Os pastéis coloridos são uma delícia e as crianças ficaram encantadas.',
      decade: '80s',
      image: 'https://images.pexels.com/photos/3771787/pexels-photo-3771787.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
    },
    {
      name: 'João Pedro, 28 anos',
      role: 'Designer',
      rating: 5,
      comment: 'Cresci nos anos 90 e o Refúgio 90 é incrível! Jogar videogame vintage enquanto como uma coxinha cassete é a experiência mais nostálgica que já tive.',
      decade: '90s',
      image: 'https://images.pexels.com/photos/1043473/pexels-photo-1043473.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
    },
    {
      name: 'Família Oliveira',
      role: 'Clientes Regulares',
      rating: 5,
      comment: 'Trouxemos três gerações da família e cada um se identificou com uma década diferente. É o único lugar onde vovó, pais e filhos se divertem juntos!',
      decade: 'Multi',
      image: 'https://images.pexels.com/photos/3811867/pexels-photo-3811867.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
    },
    {
      name: 'Roberto Santos, 35 anos',
      role: 'Advogado',
      rating: 5,
      comment: 'A qualidade dos produtos é excepcional. Ingredientes frescos, preparo artesanal e um atendimento que faz você se sentir em casa. Já virou tradição familiar!',
      decade: 'Qualidade',
      image: 'https://images.pexels.com/photos/1438081/pexels-photo-1438081.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
    }
  ];

  const decadeColors = {
    '60s': 'from-purple-500 to-pink-500',
    '70s': 'from-orange-500 to-yellow-500',
    '80s': 'from-cyan-500 to-blue-500',
    '90s': 'from-green-500 to-teal-500',
    'Multi': 'from-purple-500 via-blue-500 to-green-500',
    'Qualidade': 'from-yellow-500 to-pink-500'
  };

  return (
    <section id="reviews" className="py-20 bg-gradient-to-b from-amber-50 to-yellow-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-amber-900 mb-6">
            O Que Dizem Nossos Clientes
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-yellow-500 to-pink-500 mx-auto mb-8"></div>
          <p className="text-xl text-amber-800 max-w-3xl mx-auto leading-relaxed">
            Histórias reais de clientes que encontraram na Dreams Confectionery muito mais que 
            uma padaria - encontraram um lar para suas memórias e afetos.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {reviews.map((review, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 relative overflow-hidden"
            >
              {/* Decorative gradient */}
              <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${decadeColors[review.decade as keyof typeof decadeColors]}`}></div>
              
              <div className="flex items-center mb-4">
                <img
                  src={review.image}
                  alt={review.name}
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div className="flex-grow">
                  <h4 className="font-semibold text-amber-900">{review.name}</h4>
                  <p className="text-sm text-amber-700">{review.role}</p>
                </div>
                <div className="flex items-center space-x-1">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-yellow-500 fill-current" />
                  ))}
                </div>
              </div>

              <div className="relative">
                <Quote className="absolute -top-2 -left-2 w-8 h-8 text-amber-200 opacity-50" />
                <p className="text-amber-800 leading-relaxed pl-6">
                  {review.comment}
                </p>
              </div>

              <div className="mt-4 pt-4 border-t border-amber-100">
                <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold text-white bg-gradient-to-r ${decadeColors[review.decade as keyof typeof decadeColors]}`}>
                  {review.decade === 'Multi' ? 'Experiência Completa' : 
                   review.decade === 'Qualidade' ? 'Qualidade Premium' : 
                   `Década ${review.decade}`}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Statistics */}
        <div className="bg-gradient-to-r from-amber-800 to-amber-900 text-amber-100 rounded-2xl p-8">
          <div className="grid md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">4.9/5</div>
              <p className="text-sm">Avaliação Média</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">500+</div>
              <p className="text-sm">Avaliações Positivas</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">95%</div>
              <p className="text-sm">Clientes Satisfeitos</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">3 Gen</div>
              <p className="text-sm">Gerações Atendidas</p>
            </div>
          </div>
          
          <div className="text-center mt-6">
            <p className="text-lg italic">
              "Mais que uma padaria, somos um ponto de encontro entre gerações, 
              onde cada visita se torna uma memória especial."
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Reviews;