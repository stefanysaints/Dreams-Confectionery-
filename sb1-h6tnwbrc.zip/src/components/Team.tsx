import React from 'react';
import { Star, Award, Clock } from 'lucide-react';

const Team = () => {
  const teamMembers = [
    {
      name: 'Marina Santos',
      role: 'Gerente Geral',
      specialty: 'Atendimento excepcional',
      experience: '8 anos',
      image: 'https://images.pexels.com/photos/3785077/pexels-photo-3785077.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      description: 'Especialista em criar experiências memoráveis para cada cliente.'
    },
    {
      name: 'Carlos Mendes',
      role: 'Confeiteiro Chefe',
      specialty: 'Bolos temáticos',
      experience: '12 anos',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      description: 'Mestre na arte da confeitaria clássica e criações nostálgicas.'
    },
    {
      name: 'Ana Costa',
      role: 'Padeira Artesanal',
      specialty: 'Pães tradicionais',
      experience: '10 anos',
      image: 'https://images.pexels.com/photos/3771787/pexels-photo-3771787.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      description: 'Especializada em fermentação natural e receitas familiares.'
    },
    {
      name: 'Roberto Silva',
      role: 'Decorador Temático',
      specialty: 'Ambientação retrô',
      experience: '6 anos',
      image: 'https://images.pexels.com/photos/1043473/pexels-photo-1043473.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      description: 'Responsável por manter a autenticidade de cada ambiente.'
    },
    {
      name: 'Júlia Oliveira',
      role: 'Atendente Senior',
      specialty: 'Relacionamento com clientes',
      experience: '5 anos',
      image: 'https://images.pexels.com/photos/3811867/pexels-photo-3811867.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      description: 'Conhece a história por trás de cada produto e ambiente.'
    },
    {
      name: 'Pedro Alves',
      role: 'Barista Retrô',
      specialty: 'Cafés especiais',
      experience: '4 anos',
      image: 'https://images.pexels.com/photos/1438081/pexels-photo-1438081.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      description: 'Especialista em cafés artesanais e bebidas nostálgicas.'
    }
  ];

  return (
    <section id="team" className="py-20 bg-gradient-to-b from-yellow-100 to-amber-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-amber-900 mb-6">
            Nossa Equipe
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-yellow-500 to-pink-500 mx-auto mb-8"></div>
          <p className="text-xl text-amber-800 max-w-3xl mx-auto leading-relaxed">
            Profissionais apaixonados que compartilham o amor pela confeitaria artesanal 
            e pelo atendimento caloroso que faz a diferença.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {teamMembers.map((member, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-500 transform hover:-translate-y-2"
            >
              <div className="relative overflow-hidden">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-amber-900/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>

              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="text-xl font-serif font-bold text-amber-900">
                      {member.name}
                    </h3>
                    <p className="text-amber-700 font-medium">{member.role}</p>
                  </div>
                  <div className="flex items-center space-x-1 text-yellow-500">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                </div>

                <p className="text-amber-700 text-sm mb-4 leading-relaxed">
                  {member.description}
                </p>

                <div className="space-y-2">
                  <div className="flex items-center space-x-2 text-sm">
                    <Award className="w-4 h-4 text-yellow-600" />
                    <span className="text-amber-700">
                      <strong>Especialidade:</strong> {member.specialty}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <Clock className="w-4 h-4 text-yellow-600" />
                    <span className="text-amber-700">
                      <strong>Experiência:</strong> {member.experience}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Team Values */}
        <div className="bg-gradient-to-r from-amber-800 to-amber-900 text-amber-100 rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-serif font-bold mb-4">
            Atendimento que Encanta
          </h3>
          <p className="text-lg max-w-4xl mx-auto leading-relaxed">
            Nossa equipe é treinada não apenas nas técnicas culinárias, mas também na arte de 
            criar conexões genuínas. Cada membro conhece profundamente a história dos nossos 
            ambientes e produtos, proporcionando uma experiência completa e personalizada para 
            cada visitante que entra pela nossa porta.
          </p>
          
          <div className="grid md:grid-cols-3 gap-6 mt-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-400 mb-2">24h</div>
              <p className="text-sm">Preparo Artesanal Diário</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-400 mb-2">100%</div>
              <p className="text-sm">Ingredientes Naturais</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-400 mb-2">5⭐</div>
              <p className="text-sm">Atendimento Personalizado</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Team;