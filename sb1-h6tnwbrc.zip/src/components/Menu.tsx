import React, { useState } from 'react';
import { Coffee, Cake, Sandwich, Star } from 'lucide-react';

const Menu = () => {
  const [activeCategory, setActiveCategory] = useState('doces');

  const categories = [
    { id: 'doces', name: 'Doces Retrô', icon: <Cake className="w-5 h-5" /> },
    { id: 'paes', name: 'Pães Artesanais', icon: <Coffee className="w-5 h-5" /> },
    { id: 'salgados', name: 'Salgados Temáticos', icon: <Sandwich className="w-5 h-5" /> }
  ];

  const menuItems = {
    doces: [
      {
        name: 'Bolo Geladeira da Vovó',
        description: 'Receita tradicional com chocolate e biscoito, como nos anos dourados',
        price: 'R$ 8,50',
        image: 'https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        specialty: true
      },
      {
        name: 'Sonho Anos Dourados',
        description: 'Sonho recheado com doce de leite artesanal e coco ralado',
        price: 'R$ 6,00',
        image: 'https://images.pexels.com/photos/1854655/pexels-photo-1854655.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop'
      },
      {
        name: 'Torta Discoteca 70',
        description: 'Torta de chocolate com camadas coloridas inspirada nos anos 70',
        price: 'R$ 12,90',
        image: 'https://images.pexels.com/photos/1126359/pexels-photo-1126359.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        specialty: true
      },
      {
        name: 'Brigadeirão Retrô',
        description: 'Brigadeirão gigante com granulado colorido anos 80',
        price: 'R$ 15,50',
        image: 'https://images.pexels.com/photos/1854652/pexels-photo-1854652.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop'
      },
      {
        name: 'Pudim da Casa 90',
        description: 'Pudim de leite condensado com calda de caramelo especial',
        price: 'R$ 7,80',
        image: 'https://images.pexels.com/photos/1448721/pexels-photo-1448721.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop'
      },
      {
        name: 'Mil-Folhas Vintage',
        description: 'Delicada massa folhada com creme patissier e frutas vermelhas',
        price: 'R$ 9,90',
        image: 'https://images.pexels.com/photos/1998633/pexels-photo-1998633.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop'
      }
    ],
    paes: [
      {
        name: 'Pão Vitrola',
        description: 'Pão artesanal em formato de disco de vinil, massa macia e crocante',
        price: 'R$ 4,50',
        image: 'https://images.pexels.com/photos/1775043/pexels-photo-1775043.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        specialty: true
      },
      {
        name: 'Pãozinho Jukebox',
        description: 'Pão francês tradicional com fermentação natural de 12 horas',
        price: 'R$ 1,20',
        image: 'https://images.pexels.com/photos/1775043/pexels-photo-1775043.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop'
      },
      {
        name: 'Pão Integral Woodstock',
        description: 'Pão integral com sementes e grãos, receita natureba dos anos 60',
        price: 'R$ 6,80',
        image: 'https://images.pexels.com/photos/1775043/pexels-photo-1775043.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop'
      },
      {
        name: 'Brioche Disco Fever',
        description: 'Brioche doce e aerado, perfeito para o café da manhã',
        price: 'R$ 5,90',
        image: 'https://images.pexels.com/photos/1775043/pexels-photo-1775043.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop'
      }
    ],
    salgados: [
      {
        name: 'Coxinha Cassete',
        description: 'Coxinha especial recheada com frango desfiado e catupiry',
        price: 'R$ 5,50',
        image: 'https://images.pexels.com/photos/4958792/pexels-photo-4958792.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
        specialty: true
      },
      {
        name: 'Pastel Neon 80',
        description: 'Pastel colorido recheado com queijo e presunto especial',
        price: 'R$ 4,80',
        image: 'https://images.pexels.com/photos/4958792/pexels-photo-4958792.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop'
      },
      {
        name: 'Empada Retrô',
        description: 'Empada individual com recheio tradicional de frango',
        price: 'R$ 6,20',
        image: 'https://images.pexels.com/photos/4958792/pexels-photo-4958792.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop'
      },
      {
        name: 'Esfirra Flipper 90',
        description: 'Esfirra aberta com carne temperada e queijo gratinado',
        price: 'R$ 7,00',
        image: 'https://images.pexels.com/photos/4958792/pexels-photo-4958792.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop'
      }
    ]
  };

  return (
    <section id="menu" className="py-20 bg-gradient-to-b from-amber-100 to-yellow-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-amber-900 mb-6">
            Cardápio Dreams
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-yellow-500 to-pink-500 mx-auto mb-8"></div>
          <p className="text-xl text-amber-800 max-w-3xl mx-auto leading-relaxed">
            Sabores autênticos com nomes que despertam a nostalgia. Cada receita é preparada 
            artesanalmente com ingredientes selecionados e muito carinho.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap justify-center mb-12 space-x-2 space-y-2 sm:space-y-0">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`flex items-center space-x-2 px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                activeCategory === category.id
                  ? 'bg-gradient-to-r from-yellow-500 to-pink-500 text-white shadow-lg'
                  : 'bg-white text-amber-800 hover:bg-amber-50 border-2 border-amber-200'
              }`}
            >
              {category.icon}
              <span>{category.name}</span>
            </button>
          ))}
        </div>

        {/* Menu Items */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {menuItems[activeCategory as keyof typeof menuItems].map((item, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
            >
              <div className="relative">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-48 object-cover"
                />
                {item.specialty && (
                  <div className="absolute top-3 right-3">
                    <div className="bg-gradient-to-r from-yellow-400 to-pink-500 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center space-x-1">
                      <Star className="w-4 h-4" />
                      <span>Especialidade</span>
                    </div>
                  </div>
                )}
              </div>

              <div className="p-6">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-xl font-serif font-bold text-amber-900">
                    {item.name}
                  </h3>
                  <span className="text-2xl font-bold text-green-600 ml-4">
                    {item.price}
                  </span>
                </div>
                <p className="text-amber-700 leading-relaxed">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <div className="bg-gradient-to-r from-amber-800 to-amber-900 text-amber-100 p-6 rounded-2xl max-w-2xl mx-auto">
            <h3 className="text-xl font-semibold mb-2">🌟 Ingredientes Naturais</h3>
            <p>
              Utilizamos apenas ingredientes frescos e naturais, sem conservantes artificiais. 
              Cada produto é preparado diariamente com técnicas artesanais tradicionais.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Menu;