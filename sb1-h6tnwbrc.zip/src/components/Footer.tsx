import React from 'react';
import { Coffee, Heart, MapPin, Phone, Mail, Instagram, Facebook } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-gradient-to-b from-amber-900 to-amber-950 text-amber-100">
      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <Coffee className="w-8 h-8 text-yellow-400" />
              <div>
                <h3 className="text-2xl font-serif font-bold text-amber-100">
                  Dreams Confectionery
                </h3>
                <p className="text-sm text-amber-300 -mt-1">Sabores que atravessam o tempo</p>
              </div>
            </div>
            <p className="text-amber-200 leading-relaxed mb-6 max-w-md">
              Mais que uma padaria, somos um portal para as memórias mais doces de cada geração. 
              Venha viver uma experiência nostálgica única em Caxias do Sul.
            </p>
            
            {/* Social Media */}
            <div>
              <h4 className="font-semibold text-amber-100 mb-3">Siga-nos</h4>
              <div className="flex space-x-3">
                <a
                  href="#"
                  className="bg-gradient-to-r from-pink-500 to-purple-500 p-2 rounded-full text-white hover:scale-110 transition-transform duration-300"
                  aria-label="Instagram"
                >
                  <Instagram className="w-5 h-5" />
                </a>
                <a
                  href="#"
                  className="bg-gradient-to-r from-blue-500 to-blue-600 p-2 rounded-full text-white hover:scale-110 transition-transform duration-300"
                  aria-label="Facebook"
                >
                  <Facebook className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold text-amber-100 mb-4">Contato</h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-yellow-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-amber-200 text-sm">
                    Rua das Memórias, 1960<br />
                    Centro Histórico<br />
                    Caxias do Sul - RS
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-yellow-400 flex-shrink-0" />
                <p className="text-amber-200 text-sm">(54) 3198-1960</p>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-yellow-400 flex-shrink-0" />
                <p className="text-amber-200 text-sm">contato@dreamsconfectionery.com.br</p>
              </div>
            </div>
          </div>

          {/* Hours */}
          <div>
            <h4 className="font-semibold text-amber-100 mb-4">Horários</h4>
            <div className="space-y-2 text-sm text-amber-200">
              <div className="flex justify-between">
                <span>Segunda a Sábado:</span>
                <span>8h - 20h</span>
              </div>
              <div className="flex justify-between">
                <span>Domingo:</span>
                <span>Fechado</span>
              </div>
            </div>

            <div className="mt-6 p-3 bg-amber-800/50 rounded-lg border border-amber-700">
              <p className="text-xs text-amber-200">
                <strong>Produtos frescos todos os dias!</strong><br />
                Chegue cedo para garantir seus favoritos.
              </p>
            </div>
          </div>
        </div>

        {/* Decades Section */}
        <div className="mt-12 pt-8 border-t border-amber-800">
          <div className="text-center mb-6">
            <h4 className="font-serif text-xl text-amber-100 mb-2">Nossas Décadas</h4>
            <p className="text-amber-300 text-sm">Cada ambiente é uma viagem no tempo</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="p-3 bg-gradient-to-br from-purple-600/20 to-pink-600/20 rounded-lg border border-purple-500/30">
              <span className="text-lg font-bold text-purple-300">60s</span>
              <p className="text-xs text-amber-200 mt-1">Espaço 60</p>
            </div>
            <div className="p-3 bg-gradient-to-br from-orange-600/20 to-yellow-600/20 rounded-lg border border-orange-500/30">
              <span className="text-lg font-bold text-orange-300">70s</span>
              <p className="text-xs text-amber-200 mt-1">Sala 70</p>
            </div>
            <div className="p-3 bg-gradient-to-br from-cyan-600/20 to-blue-600/20 rounded-lg border border-cyan-500/30">
              <span className="text-lg font-bold text-cyan-300">80s</span>
              <p className="text-xs text-amber-200 mt-1">Cantinho 80</p>
            </div>
            <div className="p-3 bg-gradient-to-br from-green-600/20 to-teal-600/20 rounded-lg border border-green-500/30">
              <span className="text-lg font-bold text-green-300">90s</span>
              <p className="text-xs text-amber-200 mt-1">Refúgio 90</p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-amber-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-sm text-amber-300 text-center md:text-left">
              <p>© {currentYear} Dreams Confectionery. Todos os direitos reservados.</p>
              <p className="flex items-center justify-center md:justify-start mt-1">
                Feito com <Heart className="w-4 h-4 text-red-400 mx-1" /> em Caxias do Sul
              </p>
            </div>
            
            <button
              onClick={scrollToTop}
              className="bg-gradient-to-r from-yellow-500 to-pink-500 hover:from-yellow-600 hover:to-pink-600 text-white px-6 py-2 rounded-full text-sm font-semibold transition-all duration-300 transform hover:scale-105"
            >
              Voltar ao Topo
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;