import React from 'react';
import { ArrowRight, MapPin } from 'lucide-react';

const Hero = () => {
  const scrollToMenu = () => {
    const element = document.querySelector('#menu');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToContact = () => {
    const element = document.querySelector('#contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: 'url("https://images.pexels.com/photos/1070946/pexels-photo-1070946.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop")',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-amber-900/80 via-amber-800/60 to-amber-900/80"></div>
      </div>

      {/* Floating Elements */}
      <div className="absolute top-20 left-10 w-16 h-16 bg-yellow-400/20 rounded-full animate-pulse"></div>
      <div className="absolute top-40 right-20 w-12 h-12 bg-pink-400/20 rounded-full animate-pulse delay-1000"></div>
      <div className="absolute bottom-40 left-20 w-20 h-20 bg-blue-400/20 rounded-full animate-pulse delay-2000"></div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-5xl md:text-7xl font-serif font-bold text-amber-100 mb-4 leading-tight">
            Dreams
            <span className="block text-4xl md:text-6xl text-yellow-300">Confectionery</span>
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-yellow-400 to-pink-400 mx-auto mb-6"></div>
          <p className="text-xl md:text-2xl text-amber-200 font-light italic">
            Sabores que atravessam o tempo
          </p>
        </div>

        <p className="text-lg md:text-xl text-amber-100 mb-8 max-w-2xl mx-auto leading-relaxed">
          Embarque em uma viagem nostálgica através dos sabores e memórias das décadas douradas. 
          Nossa padaria une gerações através da culinária artesanal e do charme retrô.
        </p>

        <div className="flex items-center justify-center mb-8">
          <MapPin className="w-5 h-5 text-yellow-400 mr-2" />
          <span className="text-amber-200">Caxias do Sul, RS</span>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={scrollToMenu}
            className="group bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-amber-900 px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 transform hover:scale-105 shadow-lg"
          >
            <span className="flex items-center justify-center">
              Conheça nosso cardápio
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </span>
          </button>
          
          <button
            onClick={scrollToContact}
            className="group border-2 border-amber-200 text-amber-200 hover:bg-amber-200 hover:text-amber-900 px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 transform hover:scale-105"
          >
            <span className="flex items-center justify-center">
              Visite-nos
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </span>
          </button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <div className="w-6 h-10 border-2 border-amber-200 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-amber-200 rounded-full mt-2 animate-bounce"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;