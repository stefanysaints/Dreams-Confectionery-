import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, Instagram, Facebook } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
    type: 'duvida'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    alert('Mensagem enviada com sucesso! Entraremos em contato em breve.');
    setFormData({ name: '', email: '', phone: '', message: '', type: 'duvida' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section id="contact" className="py-20 bg-gradient-to-b from-yellow-50 to-amber-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-amber-900 mb-6">
            Venha nos Visitar
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-yellow-500 to-pink-500 mx-auto mb-8"></div>
          <p className="text-xl text-amber-800 max-w-3xl mx-auto leading-relaxed">
            Estamos ansiosos para recebê-lo em nossa viagem no tempo! Entre em contato 
            para dúvidas, sugestões ou para reservar seu momento nostálgico.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-serif font-bold text-amber-900 mb-6">
                Informações de Contato
              </h3>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-gradient-to-r from-yellow-500 to-pink-500 p-3 rounded-full">
                    <MapPin className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-amber-900 mb-1">Endereço</h4>
                    <p className="text-amber-700">
                      Rua das Memórias, 1960<br />
                      Centro Histórico, Caxias do Sul - RS<br />
                      CEP: 95020-000
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-gradient-to-r from-yellow-500 to-pink-500 p-3 rounded-full">
                    <Phone className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-amber-900 mb-1">Telefones</h4>
                    <p className="text-amber-700">
                      (54) 3198-1960<br />
                      WhatsApp: (54) 99876-5432
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-gradient-to-r from-yellow-500 to-pink-500 p-3 rounded-full">
                    <Mail className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-amber-900 mb-1">E-mail</h4>
                    <p className="text-amber-700">
                      contato@dreamsconfectionery.com.br<br />
                      encomendas@dreamsconfectionery.com.br
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-gradient-to-r from-yellow-500 to-pink-500 p-3 rounded-full">
                    <Clock className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-amber-900 mb-1">Horário de Funcionamento</h4>
                    <div className="text-amber-700 space-y-1">
                      <p>Segunda a Sábado: 8h às 20h</p>
                      <p>Domingo: Fechado</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Social Media */}
            <div>
              <h4 className="font-semibold text-amber-900 mb-4">Siga-nos nas Redes Sociais</h4>
              <div className="flex space-x-4">
                <a
                  href="#"
                  className="bg-gradient-to-r from-pink-500 to-purple-500 p-3 rounded-full text-white hover:scale-110 transition-transform duration-300"
                >
                  <Instagram className="w-6 h-6" />
                </a>
                <a
                  href="#"
                  className="bg-gradient-to-r from-blue-500 to-blue-600 p-3 rounded-full text-white hover:scale-110 transition-transform duration-300"
                >
                  <Facebook className="w-6 h-6" />
                </a>
              </div>
            </div>

            {/* Map */}
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <div className="bg-gradient-to-r from-amber-800 to-amber-900 text-white p-4">
                <h4 className="font-semibold">Nossa Localização</h4>
              </div>
              <div className="h-64 bg-amber-100 flex items-center justify-center">
                <div className="text-center text-amber-700">
                  <MapPin className="w-12 h-12 mx-auto mb-2" />
                  <p className="font-semibold">Dreams Confectionery</p>
                  <p className="text-sm">Centro Histórico - Caxias do Sul</p>
                  <p className="text-xs mt-2 italic">
                    * Mapa interativo disponível no site oficial
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h3 className="text-2xl font-serif font-bold text-amber-900 mb-6">
              Envie sua Mensagem
            </h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-semibold text-amber-900 mb-2">
                  Nome Completo *
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border-2 border-amber-200 rounded-lg focus:border-yellow-500 focus:outline-none transition-colors duration-300"
                  placeholder="Seu nome completo"
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-amber-900 mb-2">
                    E-mail *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border-2 border-amber-200 rounded-lg focus:border-yellow-500 focus:outline-none transition-colors duration-300"
                    placeholder="seu@email.com"
                  />
                </div>
                <div>
                  <label htmlFor="phone" className="block text-sm font-semibold text-amber-900 mb-2">
                    Telefone
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border-2 border-amber-200 rounded-lg focus:border-yellow-500 focus:outline-none transition-colors duration-300"
                    placeholder="(54) 99999-9999"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="type" className="block text-sm font-semibold text-amber-900 mb-2">
                  Tipo de Contato
                </label>
                <select
                  id="type"
                  name="type"
                  value={formData.type}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border-2 border-amber-200 rounded-lg focus:border-yellow-500 focus:outline-none transition-colors duration-300"
                >
                  <option value="duvida">Dúvidas Gerais</option>
                  <option value="reserva">Reserva de Mesa</option>
                  <option value="encomenda">Encomendas Especiais</option>
                  <option value="evento">Eventos e Festas</option>
                  <option value="sugestao">Sugestões</option>
                  <option value="reclamacao">Reclamações</option>
                </select>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-semibold text-amber-900 mb-2">
                  Mensagem *
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={5}
                  className="w-full px-4 py-3 border-2 border-amber-200 rounded-lg focus:border-yellow-500 focus:outline-none transition-colors duration-300 resize-vertical"
                  placeholder="Conte-nos como podemos ajudá-lo ou compartilhe sua experiência conosco..."
                />
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-yellow-500 to-pink-500 hover:from-yellow-600 hover:to-pink-600 text-white font-semibold py-4 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center space-x-2"
              >
                <Send className="w-5 h-5" />
                <span>Enviar Mensagem</span>
              </button>
            </form>

            <div className="mt-6 p-4 bg-amber-50 rounded-lg border-l-4 border-yellow-500">
              <p className="text-sm text-amber-800">
                <strong>Tempo de resposta:</strong> Respondemos todas as mensagens em até 24 horas. 
                Para urgências, ligue diretamente para nosso telefone.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;