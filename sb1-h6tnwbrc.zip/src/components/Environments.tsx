import React from 'react';
import { Music, Zap, Gamepad2, Disc } from 'lucide-react';

const Environments = () => {
  const environments = [
    {
      decade: 'Anos 60',
      name: 'Espaço 60',
      icon: <Music className="w-8 h-8" />,
      description: 'Psicodelia e paz & amor em cada canto. Pôsteres coloridos, móveis de linhas orgânicas e a trilha sonora da Jovem Guarda.',
      features: ['Móveis retrô autênticos', 'Pôsteres psicodélicos', 'Jukebox vintage', 'Iluminação ambiente'],
      image: 'https://images.pexels.com/photos/1090638/pexels-photo-1090638.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      color: 'from-purple-500 to-pink-500'
    },
    {
      decade: 'Anos 70',
      name: 'Sala 70',
      icon: <Disc className="w-8 h-8" />,
      description: 'O auge do disco e do rock. Discos de vinil decoram as paredes enquanto o som dos grandes sucessos embala sua experiência.',
      features: ['Coleção de vinis originais', 'Poltrona de couro vintage', 'Globo de discoteca', 'Bar temático'],
      image: 'https://images.pexels.com/photos/1619779/pexels-photo-1619779.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      color: 'from-orange-500 to-yellow-500'
    },
    {
      decade: 'Anos 80',
      name: 'Cantinho 80',
      icon: <Zap className="w-8 h-8" />,
      description: 'Neon, cores vibrantes e muita energia. O espírito rebelde e inovador dos anos 80 em cada detalhe fluorescente.',
      features: ['Luzes de neon', 'Fitas cassete', 'Cubo mágico gigante', 'Decoração metalizada'],
      image: 'https://images.pexels.com/photos/2747449/pexels-photo-2747449.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      color: 'from-cyan-500 to-blue-500'
    },
    {
      decade: 'Anos 90',
      name: 'Refúgio 90',
      icon: <Gamepad2 className="w-8 h-8" />,
      description: 'A era dourada dos videogames e dos brinquedos clássicos. Console vintage e nostalgia digital em um ambiente acolhedor.',
      features: ['Console de videogame', 'Brinquedos clássicos', 'Pôsteres de filmes cult', 'Sofá confortável'],
      image: 'https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      color: 'from-green-500 to-teal-500'
    }
  ];

  return (
    <section id="environments" className="py-20 bg-gradient-to-b from-yellow-50 to-amber-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-amber-900 mb-6">
            Ambientes Temáticos
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-yellow-500 to-pink-500 mx-auto mb-8"></div>
          <p className="text-xl text-amber-800 max-w-3xl mx-auto leading-relaxed">
            Quatro décadas, quatro experiências únicas. Escolha sua época favorita e mergulhe na nostalgia 
            enquanto saboreia nossas delícias artesanais.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {environments.map((env, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2"
            >
              <div className="relative overflow-hidden">
                <img
                  src={env.image}
                  alt={env.name}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className={`absolute inset-0 bg-gradient-to-br ${env.color} opacity-20 group-hover:opacity-30 transition-opacity duration-300`}></div>
                <div className="absolute top-4 left-4">
                  <div className={`inline-flex items-center justify-center w-12 h-12 bg-gradient-to-r ${env.color} rounded-full text-white shadow-lg`}>
                    {env.icon}
                  </div>
                </div>
                <div className="absolute bottom-4 left-4">
                  <span className="bg-white/90 px-3 py-1 rounded-full text-sm font-semibold text-amber-900">
                    {env.decade}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <h3 className="text-2xl font-serif font-bold text-amber-900 mb-3">
                  {env.name}
                </h3>
                <p className="text-amber-700 mb-4 leading-relaxed">
                  {env.description}
                </p>

                <div className="space-y-2">
                  <h4 className="font-semibold text-amber-900 text-sm uppercase tracking-wide">
                    Destaques do Ambiente:
                  </h4>
                  <div className="grid grid-cols-2 gap-2">
                    {env.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center space-x-2">
                        <div className={`w-2 h-2 bg-gradient-to-r ${env.color} rounded-full`}></div>
                        <span className="text-sm text-amber-700">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-lg text-amber-800 max-w-2xl mx-auto">
            <em>
              "Cada ambiente é uma viagem no tempo, cuidadosamente decorado com peças autênticas 
              e réplicas fiéis para criar a atmosfera perfeita de cada década."
            </em>
          </p>
        </div>
      </div>
    </section>
  );
};

export default Environments;