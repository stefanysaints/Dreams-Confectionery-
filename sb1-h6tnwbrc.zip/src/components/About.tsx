import React from 'react';
import { Users, Heart, Clock, Award } from 'lucide-react';

const About = () => {
  const founders = [
    { name: 'Stéfany', role: 'Confeiteira Chefe' },
    { name: 'Jean', role: 'Gerente Geral' },
    { name: 'Lucas', role: 'Padeiro Artesanal' },
    { name: 'Andressa', role: 'Decoradora' },
    { name: 'Fabiano', role: 'Coordenador de Vendas' }
  ];

  const values = [
    {
      icon: <Heart className="w-8 h-8" />,
      title: 'Paixão pela Tradição',
      description: 'Cada receita carrega o amor e o cuidado das gerações passadas'
    },
    {
      icon: <Clock className="w-8 h-8" />,
      title: 'Nostalgia Autêntica',
      description: 'Criamos experiências que despertam memórias afetivas especiais'
    },
    {
      icon: <Award className="w-8 h-8" />,
      title: 'Qualidade Artesanal',
      description: 'Ingredientes selecionados e preparo cuidadoso em cada produto'
    }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-b from-amber-50 to-yellow-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-amber-900 mb-6">
            Nossa História
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-yellow-500 to-pink-500 mx-auto mb-8"></div>
          <p className="text-xl text-amber-800 max-w-3xl mx-auto leading-relaxed">
            Nascida do sonho de cinco amigos apaixonados pela confeitaria, a Dreams Confectionery 
            é mais que uma padaria - é uma ponte entre gerações.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div className="space-y-6">
            <h3 className="text-3xl font-serif font-bold text-amber-900 mb-4">
              O Sonho que se Tornou Realidade
            </h3>
            <p className="text-lg text-amber-800 leading-relaxed">
              Em 2023, cinco amigos unidos pela paixão em confeitaria e pela nostalgia das décadas 
              douradas decidiram criar um espaço único em Caxias do Sul. Nossa missão é despertar 
              memórias afetivas através de sabores autênticos e um ambiente que celebra o melhor 
              de cada época.
            </p>
            <p className="text-lg text-amber-800 leading-relaxed">
              Cada ambiente da nossa padaria foi cuidadosamente pensado para transportar nossos 
              visitantes para diferentes momentos da história, criando uma experiência sensorial 
              completa que vai muito além do paladar.
            </p>
            <div className="flex items-center space-x-2 text-amber-700">
              <Users className="w-5 h-5" />
              <span className="font-semibold">Unidos pela paixão, movidos pela nostalgia</span>
            </div>
          </div>

          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.pexels.com/photos/1307698/pexels-photo-1307698.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
                alt="Fundadores da Dreams Confectionery"
                className="w-full h-96 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-amber-900/40 to-transparent"></div>
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-4 -right-4 w-16 h-16 bg-yellow-400/30 rounded-full"></div>
            <div className="absolute -bottom-4 -left-4 w-20 h-20 bg-pink-400/30 rounded-full"></div>
          </div>
        </div>

        {/* Founders */}
        <div className="mb-16">
          <h3 className="text-3xl font-serif font-bold text-amber-900 text-center mb-12">
            Nossos Fundadores
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
            {founders.map((founder, index) => (
              <div key={index} className="text-center group">
                <div className="w-20 h-20 bg-gradient-to-br from-yellow-400 to-pink-400 rounded-full flex items-center justify-center mb-3 mx-auto group-hover:scale-110 transition-transform duration-300">
                  <span className="text-2xl font-bold text-amber-900">
                    {founder.name[0]}
                  </span>
                </div>
                <h4 className="font-semibold text-amber-900 text-lg">{founder.name}</h4>
                <p className="text-amber-700 text-sm">{founder.role}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Values */}
        <div>
          <h3 className="text-3xl font-serif font-bold text-amber-900 text-center mb-12">
            Nossos Valores
          </h3>
          <div className="grid md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center group">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-yellow-400 to-pink-400 rounded-full text-amber-900 mb-6 group-hover:scale-110 transition-transform duration-300">
                  {value.icon}
                </div>
                <h4 className="text-xl font-semibold text-amber-900 mb-4">{value.title}</h4>
                <p className="text-amber-700 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;