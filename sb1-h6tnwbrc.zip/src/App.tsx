import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Environments from './components/Environments';
import Menu from './components/Menu';
import Team from './components/Team';
import Reviews from './components/Reviews';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-amber-50">
      <Header />
      <Hero />
      <About />
      <Environments />
      <Menu />
      <Team />
      <Reviews />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;